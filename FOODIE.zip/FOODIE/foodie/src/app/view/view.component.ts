import { Component, OnInit } from '@angular/core';
import { FoodieService } from '../foodie.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  food:any;


  constructor(private fs : FoodieService) { this.viewrecord();}
  
  data1!:any;
  ngOnInit(): void {}
      viewrecord()
      { 
      this.fs.viewdata1().subscribe(
        (response)=>{this.data1=response}
      );
    }
      }



