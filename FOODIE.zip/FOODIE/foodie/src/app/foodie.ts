export class Foodie {
    item_id = Number ;
	item_name = String ;
    item_category = String ;
	price = Number ;
}
