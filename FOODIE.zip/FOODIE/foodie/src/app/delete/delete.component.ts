import { Component, OnInit } from '@angular/core';
import { FoodieService } from '../foodie.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(private fs : FoodieService) { this.deletedata}

  ngOnInit(): void {
  }


  deletedata(deleteform: { value: any; })
 {
  
     this.fs.deleted(deleteform.value).subscribe();
  }
 } 

