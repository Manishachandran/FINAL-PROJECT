import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AddComponent } from './add/add.component';

import { ContactComponent } from './contact/contact.component';
import { DeleteComponent } from './delete/delete.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';

import { LoginComponent } from './login/login.component';
import { ServicesComponent } from './services/services.component';
import { SignupComponent } from './signup/signup.component';
import { UpdateComponent } from './update/update.component';
import { UserComponent } from './user/user.component';
import { ViewComponent } from './view/view.component';

const routes: Routes = [
  {path: 'about', component:AboutComponent},
  {path: 'contact', component:ContactComponent},
  {path: 'login', component:LoginComponent},
  {path: 'signup', component:SignupComponent},
  
  {path: 'user', component:UserComponent},
  {path: 'home', component:HomeComponent},
  {path: 'header', component:HeaderComponent},
  {path: 'add', component:AddComponent},
  {path: 'services', component:ServicesComponent},
  {path: 'view', component:ViewComponent},
  {path: 'delete', component:DeleteComponent},
  {path: 'update', component:UpdateComponent},
  {path: 'footer', component:FooterComponent},
 
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
