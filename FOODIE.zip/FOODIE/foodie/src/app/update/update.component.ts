import { Component, OnInit } from '@angular/core';
import { FoodieService } from '../foodie.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  constructor(private fs : FoodieService)
  {

  }

  ngOnInit(): void {
  }

  updatedata(updateform: any)
  {
    this.fs.updated(updateform.value).subscribe();

  }

}
