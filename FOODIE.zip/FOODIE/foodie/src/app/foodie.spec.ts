import { Foodie } from './foodie';

describe('Foodie', () => {
  it('should create an instance', () => {
    expect(new Foodie()).toBeTruthy();
  });
});
