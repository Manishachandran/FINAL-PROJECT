import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FoodieService {
  viewd() {
    throw new Error('Method not implemented.');
  }

  url="http://localhost:9000/insert";
  url1 = "http://localhost:9000/delete";
  url2 = "http://localhost:9000/update";
  url3 = "http://localhost:9000/view";
  constructor(private http : HttpClient) { }

public insertd(data: any)
{
  return this.http.post(this.url,data);

}

public deleted(data:any)
{
  return this.http.post(this.url1,data);
}

public updated(data: any)
{
  return this.http.post(this.url2,data);

}

public viewdata1()
{
  return this.http.get(this.url3);
}

  
 

}
